import React from 'react';

function Details() {
  return (
    <div className="App">
      <h1>Details</h1>
    </div>
  );
}

export default Details;
